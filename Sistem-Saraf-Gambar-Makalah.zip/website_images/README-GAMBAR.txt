GAMBAR WEBSITE SISTEM SARAF

Semua gambar di folder images/ diekstrak dari makalah "Kerangka Makalah Anfisman Sistem Sarafffff.docx".

Pemetaan ke website:
1. neuron.jpg          -> Bagian Struktur Neuron (Gambar 3 di makalah)
2. sel-glia.jpg        -> Bagian Sel Glia (Gambar 4 di makalah)
3. potensial-aksi.jpeg -> Bagian Potensial Aksi (Gambar 2 di makalah)
4. cerebrum.jpeg       -> Bagian Cerebrum / Otak Besar
5. cerebellum.png      -> Bagian Cerebellum / Otak Kecil
6. batang-otak.jpeg    -> Bagian Batang Otak (Gambar 5)
7. diensefalon.jpg     -> Bagian Diensefalon (Gambar 6)
8. medula-spinalis.jpg -> Bagian Medula Spinalis (Gambar 7)
9. saraf-spinal.jpeg   -> Bagian Saraf Spinal (Gambar 8)
10. saraf-kranial.png  -> Bagian Saraf Kranial (Gambar 9)
11. saraf-otonom.png   -> Bagian Sistem Saraf Otonom (Gambar 10)
12. bells-palsy.png    -> Bagian Gangguan Sistem Saraf / Bell's Palsy

Catatan: gambar logo universitas tidak dimasukkan karena bukan materi sistem saraf.
Gambar cerebellum yang identik/duplikat hanya dipakai satu kali.
